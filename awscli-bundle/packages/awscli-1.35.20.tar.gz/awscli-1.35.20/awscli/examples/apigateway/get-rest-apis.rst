**To get a list of REST APIs**

Command::

  aws apigateway get-rest-apis

Output::

  {
      "items": [
          {
              "createdDate": 1438884790, 
              "id": "12s44z21rb", 
              "name": "My First API"
          }
      ]
  }
